Sources

https://github.com/AlexNabokikh/nix-config
https://github.com/nix-community/kickstart-nix.nvim
